const cloudRegion = 'europe-west1';
const storeKeyConsumable = 'purchase_course';
const storeKeyUpgrade = 'course_update';
const storeKeySubscription = 'subscription_course_id';
