const String errorImage =
    'https://developers.google.com/maps/documentation/maps-static/images/error-image-generic.png';
