class Paths {
  static const String courses = 'dev-course';
  static const String users = 'users';

  // sub collection

  static const String chapters = 'chapters';
}
